package com.igorwojda.showcase.favourite.presentation

import org.koin.dsl.module

internal val presentationModule = module { }
