package com.igorwojda.showcase.favourite.domain

import org.koin.dsl.module

internal val domainModule = module { }
