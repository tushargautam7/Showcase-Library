plugins {
    id("com.android.application")
    id("local.kotlin")
    id("local.spotless")
    id("com.google.devtools.ksp")
}
