plugins {
    id("local.detekt")
    id("local.spotless")
}
