package com.igorwojda.showcase.profile.domain

import org.koin.dsl.module

internal val domainModule = module { }
