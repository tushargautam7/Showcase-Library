package com.igorwojda.showcase.profile.presentation

import org.koin.dsl.module

internal val presentationModule = module { }
