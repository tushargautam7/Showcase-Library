package com.igorwojda.showcase.profile.data

import org.koin.dsl.module

internal val dataModule = module { }
