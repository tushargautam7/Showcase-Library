package com.igorwojda.showcase.album.domain.enum

internal enum class ImageSize {
    SMALL,
    MEDIUM,
    LARGE,
    EXTRA_LARGE,
    MEGA,
}
