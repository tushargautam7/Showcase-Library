package com.igorwojda.showcase.album.domain.model

internal data class Tag(
    val name: String,
)
