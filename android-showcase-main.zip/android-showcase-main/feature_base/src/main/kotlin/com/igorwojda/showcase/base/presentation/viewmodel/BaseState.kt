package com.igorwojda.showcase.base.presentation.viewmodel

interface BaseState
